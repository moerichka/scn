import FeedPage from "./FeedPage";

export default FeedPage;
