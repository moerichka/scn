import AuthorizationPage from "./AuthorizationPage";

export default AuthorizationPage